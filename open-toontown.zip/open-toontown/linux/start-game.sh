#!/bin/sh
cd ..

export LOGIN_TOKEN=dev

python3 -m toontown.launcher.QuickStartLauncher
