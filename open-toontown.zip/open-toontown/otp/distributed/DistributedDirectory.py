from direct.distributed.DistributedObject import DistributedObject

class DistributedDirectory(DistributedObject):
    pass
