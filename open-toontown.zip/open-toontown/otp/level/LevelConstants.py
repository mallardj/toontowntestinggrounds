MinZoneNum = 0
MaxZoneNum = 999
UberZoneEntId = 0
LevelMgrEntId = 1000
EditMgrEntId = 1001
