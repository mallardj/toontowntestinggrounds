SCMenuFinalizePriority = 48
SCElementFinalizePriority = 47
